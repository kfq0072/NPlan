var searchData=
[
  ['_5f_5fdeprecated_5fmsg',['__deprecated_msg',['../interface_b_m_k_location_service.html#a978bac65e039cf58117e9a69ea259c59',1,'BMKLocationService::__deprecated_msg()'],['../interface_b_m_k_location_service.html#ad19fcf8c6b43617bd0f8771aafdc744e',1,'BMKLocationService::__deprecated_msg()']]],
  ['_5f_5fosx_5favailable_5fstarting',['__OSX_AVAILABLE_STARTING',['../interface_b_m_k_annotation_view.html#a54d15e7cc4e89d89d2233ec7fc408ad9',1,'BMKAnnotationView::__OSX_AVAILABLE_STARTING(__MAC_NA, __IPHONE_3_2)'],['../interface_b_m_k_annotation_view.html#a623e818d48c983176a6553104b21a34c',1,'BMKAnnotationView::__OSX_AVAILABLE_STARTING(__MAC_NA, __IPHONE_3_2)']]]
];
